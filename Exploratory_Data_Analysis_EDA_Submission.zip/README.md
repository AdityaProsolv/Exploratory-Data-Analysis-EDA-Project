# Exploratory Data Analysis (EDA) Project

## Objective
Analyze a sales dataset to uncover patterns, trends, relationships, and useful business insights.

## Dataset
- Rows: 120
- Columns: 10
- Numeric variables: units, unit_price, discount, revenue, customer_rating, net_unit_price
- Categorical variables: region, category, month

## EDA Activities
1. Descriptive statistics
2. Missing-value review
3. Correlation analysis
4. Distribution analysis
5. Category and region comparisons
6. Time-trend analysis
7. Relationship analysis using scatter plots
8. Structured business insights

## Key Insights
- Total revenue in the analyzed dataset is 94,214.25, with an average order revenue of 785.12.
- The median order revenue is 436.00, showing the typical order size without being heavily influenced by extreme values.
- Furniture is the highest-revenue category, while Electronics contributes the least total revenue.
- East is the strongest region by revenue, whereas South is the weakest among the regions represented.
- Units and revenue have a correlation of 0.37; this indicates a weak linear relationship in this dataset.
- Customer rating and revenue have a correlation of 0.04, suggesting a limited linear association.

## Deliverables
- `eda_dataset.csv` — dataset used for the analysis
- `exploratory_data_analysis.ipynb` — reproducible Python notebook
- `report.html` — structured EDA report
- `statistical_summary.csv`
- `missing_values_summary.csv`
- `correlation_matrix.csv`
- `figures/` — all charts used in the report
